-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2023 at 05:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coupon_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_brands`
--

CREATE TABLE `affiliate_brands` (
  `sr` int(11) NOT NULL,
  `affiliate_brand_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `affiliate_brands`
--

INSERT INTO `affiliate_brands` (`sr`, `affiliate_brand_email`) VALUES
(21, ''),
(22, ''),
(23, ''),
(24, ''),
(25, ''),
(26, ''),
(27, '');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brand` varchar(255) NOT NULL,
  `brand_contact` int(11) DEFAULT NULL,
  `brand_email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brand`, `brand_contact`, `brand_email`) VALUES
('7 Eleven', 2147483647, '7eleven@example.com'),
('Airbnb', 2147483647, 'airbnb@example.com'),
('Akash', 2147483647, 'akash@example.com'),
('Alienware', 2147483647, 'alienware@example.com'),
('Amazon', 2147483647, 'amazon@example.com'),
('American Tourister', 2147483647, 'americantourister@example.com'),
('Bata', 2147483647, 'bata@example.com'),
('CalvinKlein', 2147483647, 'calvinklein@example.com'),
('Crocs', 2147483647, 'crocs@example.com'),
('Dell', 2147483647, 'dell@example.com'),
('Dominos', 2147483647, 'dominos@example.com'),
('Dyson', 2147483647, 'dyson@example.com'),
('edX', 2147483647, 'edx@example.com'),
('fitbit', 2147483647, 'fitbit@example.com'),
('Gap', 2147483647, 'gap@example.com'),
('H & M', 2147483647, 'sammehta063@gmail.com'),
('HP', 2147483647, 'hp@example.com'),
('Hyper', 2147483647, 'hyper@example.com'),
('Ibis', 2147483647, 'ibis@example.com'),
('Icici Lombard', 2147483647, 'icicilombard@example.com'),
('Intel', 2147483647, 'intel@example.com'),
('Knorr', 2147483647, 'knorr@example.com'),
('Lego', 2147483647, 'lego@example.com'),
('LG', 2147483647, 'lg@example.com'),
('Liberty Mutual', 2147483647, 'libertymutual@example.com'),
('LIC', 2147483647, 'lic@example.com'),
('Logitech', 2147483647, 'logitech@example.com'),
('Marriot', 2109876543, 'marriot@example.com'),
('Meal', 1234567890, 'meal@example.com'),
('Motorola', 2147483647, 'motorola@example.com'),
('MSI', 2147483647, 'msi@example.com'),
('Nestle Fitness', 1098765432, 'nestlefitness@example.com'),
('Netflix', 2109876543, 'netflix@example.com'),
('Neutrogena', 2147483647, 'neutrogena@example.com'),
('New Era', 2147483647, 'newera@example.com'),
('Nintendo', 2147483647, 'nintendo@example.com'),
('Novotel', 2147483647, 'novotel@example.com'),
('Panasonic', 2147483647, 'panasonic@example.com'),
('PlayStation', 2147483647, 'playstation@example.com'),
('Predator', 2147483647, 'predator@example.com'),
('Puma', 2147483647, 'puma@example.com'),
('PVR', 2147483647, 'pvr@example.com'),
('ROG', 2147483647, 'rog@example.com'),
('Samarth Birdawade', 2147483647, 'sammehta063@gmail.com'),
('Starbucks', 2147483647, 'starbucks@example.com'),
('StarkIndustries', 2147483647, 'starkindustries@example.com'),
('Subway', 2147483647, 'subway@example.com'),
('Tripadvisor', 2147483647, 'tripadvisor@example.com'),
('Twitch', 2147483647, 'twitch@example.com'),
('Walmart', 2147483647, 'walmart@example.com'),
('World Gym', 2147483647, 'worldgym@example.com');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `Cust_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `Cust_ID`) VALUES
(4, 21);

-- --------------------------------------------------------

--
-- Table structure for table `cart_master`
--

CREATE TABLE `cart_master` (
  `cart_id` int(11) DEFAULT NULL,
  `Coupon_id` int(11) DEFAULT NULL,
  `sr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_name`) VALUES
('Clothing'),
('Education'),
('Electronics'),
('Fitness'),
('Food'),
('Luxury'),
('Meal'),
('Medical'),
('Vacation');

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `Coupon_id` int(11) NOT NULL,
  `coupon_desc` text DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `expiry` date DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image_src` varchar(255) DEFAULT NULL,
  `cost_price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`Coupon_id`, `coupon_desc`, `brand`, `quantity`, `expiry`, `price`, `category`, `image_src`, `cost_price`) VALUES
(128, 'Get 10% off upto ₹175/-', 'Panasonic', 3450, '2024-08-30', 2099.00, 'Electronics', 'images used/Logos/Panasonic.png', 1799),
(129, 'Get 15% off upto ₹175/-', 'Amazon', 950, '2024-05-29', 4099.00, 'Clothing', 'images used/Logos/Amazon.png', 9499),
(130, 'Get 20% off', 'CalvinKlein', 4000, '2023-11-23', 9499.00, 'Clothing', 'images used/Logos/CalvinKlein.png', 5499),
(131, 'Get 30% off', 'LG', 3750, '2024-01-04', 6899.00, 'Electronics', 'images used/Logos/LG.png', 7499),
(132, 'Get 15% off upto ₹200/-', 'Puma', 3650, '2024-03-31', 9099.00, 'Clothing', 'images used/Logos/Puma.png', 2899),
(133, 'Get 10% off upto ₹600/-', 'Akash', 2350, '2024-06-06', 6599.00, 'Education', 'images used/Logos/Akash.png', 3699),
(134, 'Get 15% off upto ₹2000/-', 'Novotel', 3550, '2024-05-29', 7899.00, 'Vacation', 'images used/Logos/Novotel.png', 1699),
(135, 'Get 20% off upto ₹200/-', 'World Gym', 10, '2024-01-09', 6899.00, 'Fitness', 'images used/Logos/World Gym.png', 7099),
(136, 'Get free Twitch prime', 'Twitch', 50, '2024-05-04', 5099.00, 'Luxury', 'images used/Logos/Twitch.png', 7599),
(137, 'Get 60% off', 'StarkIndustries', 2050, '2024-07-26', 5399.00, 'Electronics', 'images used/Logos/StarkIndustries.png', 2699),
(212, 'Get 25% off upto ₹175/-', 'Meal', 4600, '2024-02-12', 7099.00, 'Meal', 'images used/Logos/Meal.png', 5699),
(213, 'Get 30% off upto ₹175/-', 'Meal', 3350, '2024-07-02', 4399.00, 'Meal', 'images used/Logos/Meal.png', 8499),
(214, 'Get 35% off upto ₹175/-', 'Meal', 800, '2024-01-07', 5299.00, 'Meal', 'images used/Logos/Meal.png', 8199),
(215, 'Get 40% off upto ₹175/-', 'Dominos', 3500, '2024-10-16', 7699.00, 'Food', 'images used/Logos/Dominos.png', 8399),
(216, 'Get 5% off upto ₹200/-', '7 Eleven', 4900, '2024-02-24', 7199.00, 'Food', 'images used/Logos/7 Eleven.png', 4899),
(217, 'Get 10% off upto ₹200/-', 'American Tourister', 1000, '2024-06-08', 5099.00, 'Vacation', 'images used/Logos/American Tourister.png', 4999),
(218, 'Get 15% off upto ₹200/-', 'Bata', 4800, '2024-03-15', 9999.00, 'Clothing', 'images used/Logos/Bata.png', 8399),
(219, 'Get 20% off upto ₹200/-', 'Alienware', 10, '2024-02-01', 7599.00, 'Luxury', 'images used/Logos/Alienware.png', 8599),
(220, 'Get 25% off upto ₹200/-', 'CalvinKlein', 50, '2023-12-18', 1599.00, 'Luxury', 'images used/Logos/CalvinKlein.png', 9199),
(221, 'Get 30% off upto ₹200/-', 'Dell', 2300, '2024-04-18', 9699.00, 'Electronics', 'images used/Logos/Dell.png', 4699),
(222, 'Get 35% off upto ₹200/-', 'Dyson', 5, '2024-02-06', 1299.00, 'Luxury', 'images used/Logos/Dyson.png', 3999),
(223, 'Get 40% off upto ₹200/-', 'Meal', 3500, '2024-03-13', 7899.00, 'Meal', 'images used/Logos/Meal.png', 7499),
(224, 'Get 5% off upto ₹225/-', 'Hyper', 20, '2024-03-16', 6999.00, 'Luxury', 'images used/Logos/Hyper.png', 2699),
(225, 'Get 10% off upto ₹225/-', 'Icici lombard', 150, '2024-05-04', 5199.00, 'Medical', 'images used/Logos/Icici lombard.png', 7899),
(226, 'Get 15% off upto ₹225/-', 'Icici lombard', 2750, '2024-03-14', 2899.00, 'Medical', 'images used/Logos/Icici lombard.png', 9099),
(227, 'Get 20% off upto ₹225/-', 'Intel', 5000, '2024-01-07', 9599.00, 'Electronics', 'images used/Logos/Intel.png', 2399),
(228, 'Get 25% off upto ₹225/-', 'Knorr', 300, '2024-07-18', 4799.00, 'Food', 'images used/Logos/Knorr.png', 9299),
(229, 'Get 30% off upto ₹225/-', 'Lego', 100, '2024-04-08', 4399.00, 'Luxury', 'images used/Logos/Lego.png', 5899),
(230, 'Get 35% off upto ₹225/-', 'LIC', 3450, '2024-07-18', 5799.00, 'Medical', 'images used/Logos/LIC.png', 5399),
(231, 'Get 40% off upto ₹225/-', 'Logitech', 4650, '2023-12-06', 7499.00, 'Electronics', 'images used/Logos/Logitech.png', 3499),
(232, 'Get 5% off upto ₹250/-', 'MSI', 1650, '2024-07-20', 6699.00, 'Electronics', 'images used/Logos/MSI.png', 9699),
(233, 'Get 10% off upto ₹250/-', 'Netflix', 350, '2024-02-28', 5199.00, 'Electronics', 'images used/Logos/Netflix.png', 3699),
(234, 'Get 15% off upto ₹250/-', 'Nestle Fitness', 1200, '2024-01-03', 2599.00, 'Fitness', 'images used/Logos/Nestle Fitness.png', 4099),
(235, 'Get 20% off upto ₹250/-', 'Neutrogena', 50, '2024-02-15', 4299.00, 'Luxury', 'images used/Logos/Neutrogena.png', 9399),
(236, 'Get 25% off upto ₹250/-', 'New Era', 3250, '2024-03-18', 9699.00, 'Clothing', 'images used/Logos/New Era.png', 6799),
(237, 'Get 30% off upto ₹250/-', 'Liberty Mutual', 2250, '2024-01-13', 7199.00, 'Medical', 'images used/Logos/Liberty Mutual.png', 8199),
(238, 'Get 35% off upto ₹250/-', 'edX', 300, '2024-08-08', 7399.00, 'Education', 'images used/Logos/edX.png', 2899),
(239, 'Get 40% off upto ₹250/-', 'Novotel', 250, '2024-04-26', 3899.00, 'Vacation', 'images used/Logos/Novotel.png', 1899),
(240, 'Get ₹100/- off', 'Gap', 3300, '2024-09-27', 6199.00, 'Clothing', 'images used/Logos/Gap.png', 2299),
(241, 'Get ₹125/- off', 'Ibis', 450, '2024-10-02', 4299.00, 'Vacation', 'images used/Logos/Ibis.png', 1099),
(242, 'Get ₹150/- off', 'Marriot', 450, '2024-02-20', 3599.00, 'Vacation', 'images used/Logos/Marriot.png', 5199),
(243, 'Get ₹175/- off', 'ROG', 2900, '2024-03-27', 3899.00, 'Electronics', 'images used/Logos/ROG.png', 3999),
(244, 'Get ₹200/- off', 'Nintendo', 4000, '2024-09-29', 2799.00, 'Electronics', 'images used/Logos/Nintendo.png', 2899),
(245, 'Get ₹225/- off', 'Subway', 2850, '2023-12-17', 9599.00, 'Food', 'images used/Logos/Subway.png', 4099),
(246, 'Get ₹250/- off', 'Starbucks', 4750, '2024-06-25', 4799.00, 'Food', 'images used/Logos/Starbucks.png', 1999),
(247, 'Get ₹275/- off', 'Walmart', 2000, '2024-05-19', 6299.00, 'Food', 'images used/Logos/Walmart.png', 3399),
(248, 'Get ₹300/- off', 'World Gym', 3300, '2024-04-03', 2399.00, 'Fitness', 'images used/Logos/World Gym.png', 5199);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Cust_ID` int(11) NOT NULL,
  `Cust_email` varchar(255) DEFAULT NULL,
  `Cust_name` varchar(255) DEFAULT NULL,
  `Cust_contact` int(11) DEFAULT NULL,
  `Cust_password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Cust_ID`, `Cust_email`, `Cust_name`, `Cust_contact`, `Cust_password`) VALUES
(21, 'samarth@gmail.com', 'Samarth Birdawade', 2147483647, 'a');

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `receipt_id` int(11) NOT NULL,
  `receipt_date` date DEFAULT NULL,
  `cart_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`receipt_id`, `receipt_date`, `cart_id`) VALUES
(66, '2023-10-01', 4),
(67, '2023-10-01', 4),
(68, '2023-10-01', 4),
(69, '2023-10-01', 4),
(70, '2023-10-01', 4),
(71, '2023-10-01', 4),
(72, '2023-10-01', 4),
(73, '2023-10-01', 4),
(74, '2023-10-01', 4);

-- --------------------------------------------------------

--
-- Table structure for table `receipt_master`
--

CREATE TABLE `receipt_master` (
  `sr` int(11) NOT NULL,
  `receipt_id` int(11) DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `affiliate_brands`
--
ALTER TABLE `affiliate_brands`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brand`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `Cust_ID` (`Cust_ID`);

--
-- Indexes for table `cart_master`
--
ALTER TABLE `cart_master`
  ADD PRIMARY KEY (`sr`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `Coupon_id` (`Coupon_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_name`);

--
-- Indexes for table `coupon`
--
ALTER TABLE `coupon`
  ADD PRIMARY KEY (`Coupon_id`),
  ADD KEY `brand` (`brand`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Cust_ID`);

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`receipt_id`),
  ADD KEY `cart_id` (`cart_id`);

--
-- Indexes for table `receipt_master`
--
ALTER TABLE `receipt_master`
  ADD PRIMARY KEY (`sr`),
  ADD KEY `receipt_id` (`receipt_id`),
  ADD KEY `coupon_id` (`coupon_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `affiliate_brands`
--
ALTER TABLE `affiliate_brands`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cart_master`
--
ALTER TABLE `cart_master`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `coupon`
--
ALTER TABLE `coupon`
  MODIFY `Coupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=249;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Cust_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `receipt`
--
ALTER TABLE `receipt`
  MODIFY `receipt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `receipt_master`
--
ALTER TABLE `receipt_master`
  MODIFY `sr` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `customer` (`Cust_ID`);

--
-- Constraints for table `cart_master`
--
ALTER TABLE `cart_master`
  ADD CONSTRAINT `cart_master_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`cart_id`),
  ADD CONSTRAINT `cart_master_ibfk_2` FOREIGN KEY (`Coupon_id`) REFERENCES `coupon` (`Coupon_id`);

--
-- Constraints for table `coupon`
--
ALTER TABLE `coupon`
  ADD CONSTRAINT `coupon_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `brand` (`brand`),
  ADD CONSTRAINT `coupon_ibfk_2` FOREIGN KEY (`category`) REFERENCES `category` (`category_name`);

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `receipt_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`cart_id`);

--
-- Constraints for table `receipt_master`
--
ALTER TABLE `receipt_master`
  ADD CONSTRAINT `receipt_master_ibfk_1` FOREIGN KEY (`receipt_id`) REFERENCES `receipt` (`receipt_id`),
  ADD CONSTRAINT `receipt_master_ibfk_2` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`Coupon_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
